from .plugin import PlantUMLPlugin
